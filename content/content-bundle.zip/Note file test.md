Note file test

[[2023-06-02 20.46.54.svg]]

[[2023-06-02 20.46.54]]

21:03
have to test all of those ones, see if they open.

[[Test-2]]
